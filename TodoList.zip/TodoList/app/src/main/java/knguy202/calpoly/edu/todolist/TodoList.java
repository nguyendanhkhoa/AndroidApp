package knguy202.calpoly.edu.todolist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class TodoList extends AppCompatActivity {

    private static final String TAG = "Todo List";
    private EditText editText;
    private LinearLayout myListLayout;

    private static class Entry
    {
        String things;
        boolean isChecked;
    }

    private ArrayList<Entry> mList;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);

        myListLayout = (LinearLayout) findViewById(R.id.list_layout);

        Button button = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.edit_text);

        mList = (ArrayList<Entry>) getLastCustomNonConfigurationInstance();

        final CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox);

        if(mList == null)
        {
            mList = new ArrayList<>();
        }
        else
        {
            for(int i = 0; i< mList.size(); i++)
            {
                addListEntry(mList.get(i));
            }
        }

        editText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (editText.getText().length() > 0
                    && event.getAction() == KeyEvent.ACTION_DOWN
                    && keyCode == KeyEvent.KEYCODE_ENTER) {
                Entry entry = new Entry();
                entry.things = editText.getText().toString();
                entry.isChecked = false;

                addListEntry(entry);
                mList.add(entry);
                return true;

            } else {
                return false;
            }
            }
        });

                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = editText.getText().toString();
                        Log.d(TAG, "Blah" + text + "Blah");
                        if (!text.isEmpty()) {
                            Entry entry = new Entry();
                            entry.things = text;
                            entry.isChecked = false;

                            addListEntry(entry);
                            mList.add(entry);
                        }

                    }
                });
    }

    @Override
    public Object onRetainCustomNonConfigurationInstance()
    {
        return mList;
    }

    public void addListEntry(Entry entry)
    {
        LayoutInflater inflater = LayoutInflater.from(this);
        View v = inflater.inflate(R.layout.list_entry, myListLayout, false);

        TextView tv = (TextView) v.findViewById(R.id.textView);
        tv.setText(entry.things);

        CheckBox cb = (CheckBox) v.findViewById(R.id.checkBox);
        cb.setChecked(entry.isChecked);

        myListLayout.addView(v);
    }
    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume(){
        super.onResume();

    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        for (int i = 0; i< myListLayout.getChildCount(); i++){
            View v = myListLayout.getChildAt(i);
            CheckBox cb = (CheckBox)v.findViewById(R.id.checkBox);
            mList.get(i).isChecked = cb.isChecked();
        }
    }
}
