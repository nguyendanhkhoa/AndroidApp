package com.example.khoanguyen1.todolistfragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * Created by khoanguyen1 on 10/20/16.
 */
public class EditScreen extends AppCompatActivity implements todoItemDetailFragment.SayHello{

    private ImageView iv;
    private int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_screen);

        Intent intent = getIntent();

        id = intent.getIntExtra("id", 1);
        Bundle arguments = new Bundle();
        arguments.putInt(todoItemDetailFragment.ARG_ITEM_ID, id);
        todoItemDetailFragment fragment = new todoItemDetailFragment();
        fragment.setArguments(arguments);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.todoitem_detail_container, fragment)
                .commit();

    }


    public void sayHello(){
        finish();
    }
}
