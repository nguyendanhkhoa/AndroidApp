package com.example.khoanguyen1.todolistfragment;

import java.util.ArrayList;

/**
 * Created by khoanguyen1 on 10/20/16.
 */
public class EntryList {
    public static ArrayList<TodoListUtils.Entry> todoList = new ArrayList<>();

}
