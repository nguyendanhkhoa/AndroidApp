package knguy202.calpoly.edu.todolist;

import android.provider.BaseColumns;

/**
 * Created by khoanguyen1 on 10/24/16.
 */
public final class FeedReaderContract {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private FeedReaderContract() {
    }

    /* Inner class that defines the table contents */
    public static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "todoList";
        public static final String COLUMN_NAME_MNAME = "mName";
        public static final String COLUMN_NAME_CHECKBOX = "checkbox";
        public static final String COLUMN_NAME_IMAGEID = "imageid";
        public static final String COLUMN_NAME_DIRECTORY = "dir";
        public static final String SQL_SELECT_ENTRIES = "SELECT * FROM " + TABLE_NAME;


    }
}