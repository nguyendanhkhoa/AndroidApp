package knguy202.calpoly.edu.todolist;

import java.util.ArrayList;

/**
 * Created by khoanguyen1 on 10/20/16.
 */
public class EntryList {
    public static ArrayList<TodoListUtils.Entry> todoList = new ArrayList<>();

}
