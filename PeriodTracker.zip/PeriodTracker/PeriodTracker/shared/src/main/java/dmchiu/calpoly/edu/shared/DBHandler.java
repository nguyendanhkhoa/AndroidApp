package dmchiu.calpoly.edu.shared;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DB = "period_tracker";

    public DBHandler(Context context) {
        super(context, DB, null, DATABASE_VERSION);
    }


    public ArrayList<Category> getCategories() {
        ArrayList<Category> categories = new ArrayList<Category>();

        String selectQuery = "SELECT `" +
                "catid" +
                "name" +
                "color_code" +
                "orderby" +
                "show" +
                "icon" +
                "FROM `categories` ORDER BY `orderby` DESC";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                ArrayList<Option> options = getOptions(cursor.getInt(0));
                Category category = new Category(cursor.getInt(0), cursor.getString(1), cursor.getString(2),
                        cursor.getInt(3), cursor.getInt(4), cursor.getString(5), options);

                categories.add(category);
            } while (cursor.moveToNext());
        }

        return categories;
    }

    public Category getCategory(int categoryid) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("categories", new String[] {
                "catid",
                "name",
                "color_code",
                "orderby",
                "show",
                "icon"
                }, "catid = ?",
                new String[] {String.valueOf(categoryid)}, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        } else {
            return null;
        }

        ArrayList<Option> options = getOptions(categoryid);

        return new Category(cursor.getInt(0), cursor.getString(1), cursor.getString(2),
         cursor.getInt(3), cursor.getInt(4), cursor.getString(5), options);
    }

    public ArrayList<Option> getOptions(int catid) {
        ArrayList<Option> options = new ArrayList<Option>();

        String selectQuery = "SELECT `" +
                "optionid" +
                "catid" +
                "orderby" +
                "show" +
                "name" +
                "icon" +
                "FROM `options`";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Option opt = new Option(cursor.getInt(0), cursor.getInt(1), cursor.getInt(2),
                 cursor.getInt(3), cursor.getString(4), cursor.getString(5));

                options.add(opt);
            } while (cursor.moveToNext());
        }

        return options;
    }

    public int getLastCategoryID() {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT `catid` FROM `categories`";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor != null) {
            cursor.moveToLast();
        }

        return cursor.getInt(0);
    }

    private void createTables(SQLiteDatabase db) {
        String q_createCategories =
                "CREATE TABLE `categories` (" +
                        "`name` VARCHAR(255), " +
                        "`catid` INT(11) PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`show` TINYINT(1), " +
                        "`color_code` VARCHAR(6), " +
                        "`orderby` INT(11), " +
                        "`icon` VARCHAR(255)" +
                        ")";
        db.execSQL(q_createCategories);

        String q_createOptions =
                "CREATE TABLE `options` (" +
                        "`optionid` INT(11) PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` VARCHAR(255), " +
                        "`catid` INT(11), " +
                        "`orderby` INT(11), " +
                        "`show` TINYINT(1), " +
                        "`icon` VARCHAR(255)" +
                        ")";
        db.execSQL(q_createOptions);

        String q_createDataEntry=
                "CREATE TABLE `data_entry` (" +
                        "`day` INT(2), " +
                        "`month` INT(2), " +
                        "`year` INT(11), " +
                        "`optionid` INT(11), " +
                        "PRIMARY KEY (`day`, `month`, `year`)" +
                        ")";
        db.execSQL(q_createDataEntry);
    }

    private void addGenericCategories(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        ArrayList<String[]> rowVals = new ArrayList<String[]>();
        rowVals.add(new String[] {"Period Flow", "1", "D32F2F"});
        rowVals.add(new String[] {"Collection Method", "1", "D81B60"});
        rowVals.add(new String[] {"PMS", "1", "D81B60"});
        rowVals.add(new String[] {"Cravings", "1", "3F51B5"});

        db.beginTransaction();

        try {
            for(int i = 0; i < rowVals.size(); i++) {
                values.clear();

                values.put("name", rowVals.get(i)[0]);
                values.put("show", Integer.parseInt(rowVals.get(i)[1]));
                values.put("color_code", rowVals.get(i)[2]);
                values.put("orderby", i);
                db.insert("`categories`", null, values);

            }
            db.setTransactionSuccessful();
        }
        finally {
            db.endTransaction();
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTables(db);
        addGenericCategories(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        createTables(db);
    }
}
