package dmchiu.calpoly.edu.shared;

public class Option {
    int optionid;
    int catid;
    int orderby;
    int show;
    String name;
    String icon;

    public Option(int optionid, int catid, int orderby, int show, String name, String icon) {
        this.optionid = optionid;
        this.catid = catid;
        this.orderby = orderby;
        this.show = show;
        this.name = name;
        this.icon = icon;
    }
}
