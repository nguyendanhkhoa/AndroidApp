package dmchiu.calpoly.edu.shared;

import java.util.ArrayList;

public class Category {
    int catid;
    String name;
    String color_code;
    int orderby;
    int show;
    String icon;
    ArrayList<Option> options;

    public Category(int catid, String name, String color_code, int orderby, int show, String icon, ArrayList<Option> options) {
        this.catid = catid;
        this.name = name;
        this.color_code = color_code;
        this.orderby = orderby;
        this.show = show;
        this.icon = icon;
        this.options = options;
    }

    public Category(int catid, String name, String color_code, int orderby, int show, String icon) {
        this.catid = catid;
        this.name = name;
        this.color_code = color_code;
        this.orderby = orderby;
        this.show = show;
        this.icon = icon;
        this.options = new ArrayList<Option>();
    }

    public String getName(){
        return this.name;
    }

    public void setOptions(ArrayList<Option> options) {
        this.options = options;
    }
}
