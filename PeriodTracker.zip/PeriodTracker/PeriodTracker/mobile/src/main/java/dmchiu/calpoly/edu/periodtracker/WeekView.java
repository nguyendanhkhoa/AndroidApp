package dmchiu.calpoly.edu.periodtracker;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;

import dmchiu.calpoly.edu.shared.Category;
import dmchiu.calpoly.edu.shared.DBHandler;

public class WeekView extends AppCompatActivity {
    public static ArrayList<Category> categoriesList;
    public static DBHandler db;
    public static CategoryListAdapter categoryAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.db = new DBHandler(this);
        setContentView(R.layout.weekly_view);

        setupRecyclerView();

        Button addCategory = (Button) findViewById(R.id.addCategory);
        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), AddCategory.class);
                view.getContext().startActivity(intent);
            }
        });



    }
    public void setupRecyclerView(){
        categoriesList = new ArrayList<>();
        // It would be cool to use threads here, but that's a todo.
        //this.categoriesList = db.getCategories();

        RecyclerView rv = (RecyclerView) findViewById(R.id.rv);
        assert rv != null;

        categoriesList.add(new Category(0, "Food", "pink", 1, 1, "icon"));
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        categoryAdapter = new CategoryListAdapter(categoriesList);
        rv.setAdapter(categoryAdapter);
        categoryAdapter.notifyDataSetChanged();
    }


    public class CategoryListViewHolder extends RecyclerView.ViewHolder {

        public Button categoryButton;
        public Category category;
        public CategoryListViewHolder(View itemView) {
            super(itemView);
            categoryButton = (Button) itemView.findViewById(R.id.category);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Intent intent = new Intent(v.getContext(), EditScreen.class);
//
//                    intent.putExtra("id", CategoryListViewHolder.this.getAdapterPosition());
//                    v.getContext().startActivity(intent);

                }
            });

        }

        public void bind(final Category category) {
            this.category = category;
//            mTv.setText(entry.getName());
            categoryButton.setText(category.getName());

        }
    }
    public class CategoryListAdapter extends RecyclerView.Adapter<CategoryListViewHolder> {

        private ArrayList<Category> categoryList;

        public CategoryListAdapter(ArrayList<Category> categoryList) {
            this.categoryList = categoryList;
        }

        @Override
        public int getItemViewType(int position) {
            return R.layout.category;
        }

        @Override
        public CategoryListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new CategoryListViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false));
        }

        @Override
        public void onBindViewHolder(CategoryListViewHolder holder, int position) {
            holder.bind(categoryList.get(position));
        }

        @Override
        public int getItemCount() {
            return categoryList.size();
        }
    }
}
