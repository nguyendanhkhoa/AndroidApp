package dmchiu.calpoly.edu.periodtracker;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by khoanguyen1 on 10/30/16.
 */

public class AddCategory extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
